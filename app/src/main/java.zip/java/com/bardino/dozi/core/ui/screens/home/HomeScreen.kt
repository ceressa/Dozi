package com.bardino.dozi.core.ui.screens.home

import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.bardino.dozi.R
import com.bardino.dozi.core.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.TextStyle
import java.util.*

data class MedicineRecord(
    val time: String,
    val name: String,
    val status: MedicineStatus
)

enum class MedicineStatus {
    TAKEN, SKIPPED, PLANNED, UPCOMING
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun HomeScreen(
    contentPadding: PaddingValues = PaddingValues(),
    onNavigateToMedicines: () -> Unit,
    onNavigateToReminders: () -> Unit,
    onNavigateToProfile: () -> Unit
) {
    var showSkipDialog by remember { mutableStateOf(false) }
    var showSnoozeDialog by remember { mutableStateOf(false) }
    var showSuccessPopup by remember { mutableStateOf(false) }
    var showSkippedPopup by remember { mutableStateOf(false) }
    var timelineExpanded by remember { mutableStateOf(false) }
    var selectedDate by remember { mutableStateOf<LocalDate?>(null) }
    var snoozeMinutes by remember { mutableStateOf(0) }
    var currentMedicineStatus by remember { mutableStateOf<MedicineStatus>(MedicineStatus.UPCOMING) }
    var lastSnoozeTimestamp by remember { mutableStateOf(0L) }

    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    // ✅ İlk açılışta kalan süreyi hesapla
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("dozi_prefs", Context.MODE_PRIVATE)
        val snoozeUntil = prefs.getLong("snooze_until", 0)
        val timestamp = prefs.getLong("snooze_timestamp", 0)

        if (snoozeUntil > System.currentTimeMillis()) {
            // ✅ Kalan süreyi dakikaya çevir
            val remainingMillis = snoozeUntil - System.currentTimeMillis()
            val remainingMinutes = (remainingMillis / 60_000).toInt() + 1 // Yukarı yuvarla

            snoozeMinutes = remainingMinutes
            lastSnoozeTimestamp = timestamp
        } else if (snoozeUntil > 0) {
            // Süre dolmuş, temizle
            prefs.edit()
                .remove("snooze_minutes")
                .remove("snooze_until")
                .remove("snooze_timestamp")
                .apply()
        }
    }

    // ✅ Periyodik olarak SharedPreferences'ı kontrol et
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000) // Her saniye kontrol et
            val prefs = context.getSharedPreferences("dozi_prefs", Context.MODE_PRIVATE)
            val snoozeUntil = prefs.getLong("snooze_until", 0)
            val timestamp = prefs.getLong("snooze_timestamp", 0)

            // ✅ Sadece daha yeni bir erteleme varsa güncelle
            if (timestamp > lastSnoozeTimestamp && snoozeUntil > System.currentTimeMillis()) {
                val remainingMillis = snoozeUntil - System.currentTimeMillis()
                val remainingMinutes = (remainingMillis / 60_000).toInt() + 1

                snoozeMinutes = remainingMinutes
                lastSnoozeTimestamp = timestamp
            } else if (snoozeUntil > 0 && snoozeUntil <= System.currentTimeMillis()) {
                // Süre doldu, sıfırla
                snoozeMinutes = 0
                lastSnoozeTimestamp = 0
                prefs.edit()
                    .remove("snooze_minutes")
                    .remove("snooze_until")
                    .remove("snooze_timestamp")
                    .apply()
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFB2EBF2),
                            Color(0xFFE0F7FA),
                            Color(0xFFF1F8FB)
                        )
                    )
                )
                .padding(contentPadding)
                .then(
                    if (showSuccessPopup || showSkippedPopup) Modifier.blur(10.dp)
                    else Modifier
                )
        ) {
            DoziHeader()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
            ) {
                Spacer(Modifier.height(16.dp))

                HorizontalCalendar(
                    selectedDate = selectedDate,
                    onDateSelected = { date ->
                        selectedDate = if (selectedDate == date) null else date
                    }
                )

                Spacer(Modifier.height(20.dp))

                if (currentMedicineStatus == MedicineStatus.UPCOMING) {
                    CurrentMedicineCard(
                        snoozeMinutes = snoozeMinutes,
                        onTaken = {
                            playSound(context, R.raw.success)
                            currentMedicineStatus = MedicineStatus.TAKEN
                            showSuccessPopup = true
                            coroutineScope.launch {
                                delay(2000)
                                showSuccessPopup = false
                            }
                        },
                        onSnooze = { showSnoozeDialog = true },
                        onSkip = { showSkipDialog = true }
                    )
                } else {
                    EmptyMedicineCard(currentMedicineStatus)
                }

                Spacer(Modifier.height(24.dp))

                TimelineSection(
                    expanded = timelineExpanded,
                    onToggle = {
                        timelineExpanded = !timelineExpanded
                        if (timelineExpanded) {
                            coroutineScope.launch {
                                scrollState.animateScrollTo(
                                    scrollState.maxValue,
                                    animationSpec = tween(300, easing = FastOutSlowInEasing)
                                )
                            }
                        }
                    }
                )

                Spacer(Modifier.height(100.dp))
            }
        }

        // Calendar dropdown
        AnimatedVisibility(
            visible = selectedDate != null,
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            selectedDate?.let { date ->
                CalendarDayDetails(
                    date = date,
                    onDismiss = { selectedDate = null }
                )
            }
        }

        // Success popup
        if (showSuccessPopup) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.dozi_ok),
                    contentDescription = null,
                    modifier = Modifier.size(200.dp)
                )
            }
        }

        // Skipped popup
        if (showSkippedPopup) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.dozi_happy),
                    contentDescription = null,
                    modifier = Modifier.size(200.dp)
                )
            }
        }
    }

    if (showSkipDialog) {
        SkipReasonDialog(
            onDismiss = {
                playSound(context, R.raw.pekala)
                showSkipDialog = false
            },
            onConfirm = { reason ->
                playSound(context, R.raw.pekala)
                currentMedicineStatus = MedicineStatus.SKIPPED
                showSkipDialog = false
                showSkippedPopup = true
                coroutineScope.launch {
                    delay(2000)
                    showSkippedPopup = false
                }
            }
        )
    }

    if (showSnoozeDialog) {
        SnoozeDialog(
            onDismiss = { showSnoozeDialog = false },
            onConfirm = { minutes ->
                snoozeMinutes = minutes
                showSnoozeDialog = false
            }
        )
    }
}

fun playSound(context: Context, resourceId: Int) {
    try {
        val mediaPlayer = MediaPlayer.create(context, resourceId)
        mediaPlayer?.setOnCompletionListener { it.release() }
        mediaPlayer?.start()
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
private fun DoziHeader() {
    val hour = LocalTime.now().hour
    val greeting = when (hour) {
        in 6..11 -> "Günaydın"
        in 12..17 -> "İyi günler "
        in 18..21 -> "İyi akşamlar"
        else -> "İyi geceler"
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .shadow(8.dp, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(Color(0xFF4DD0E1), Color(0xFF26C6DA))
                )
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    greeting,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Image(
                painter = painterResource(id = R.drawable.dozi_brand),
                contentDescription = "Dozi",
                modifier = Modifier.height(75.dp)
            )
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
private fun HorizontalCalendar(
    selectedDate: LocalDate?,
    onDateSelected: (LocalDate) -> Unit
) {
    val today = LocalDate.now()
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = 15)

    val dates = remember {
        (-15..15).map { today.plusDays(it.toLong()) }
    }

    // Mock data - günlük durumlar
    val dayStatuses = remember {
        mapOf(
            today.minusDays(4) to MedicineStatus.TAKEN,
            today.minusDays(3) to MedicineStatus.TAKEN,
            today.minusDays(2) to MedicineStatus.SKIPPED,
            today.minusDays(1) to MedicineStatus.TAKEN,
            today to MedicineStatus.UPCOMING,
            today.plusDays(1) to MedicineStatus.PLANNED,
            today.plusDays(2) to MedicineStatus.PLANNED
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            today.month.getDisplayName(TextStyle.FULL, Locale("tr", "TR")).uppercase(),
            style = MaterialTheme.typography.labelLarge,
            color = DoziTurquoise,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            LazyRow(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(dates) { date ->
                    CalendarDayItem(
                        date = date,
                        isToday = date == today,
                        status = dayStatuses[date],
                        isSelected = date == selectedDate,
                        onClick = { onDateSelected(date) }
                    )
                }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
private fun CalendarDayItem(
    date: LocalDate,
    isToday: Boolean,
    status: MedicineStatus?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val dayName = date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("tr", "TR"))

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .width(70.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                when {
                    isSelected -> DoziPurple.copy(alpha = 0.15f)
                    isToday -> DoziTurquoise.copy(alpha = 0.15f)
                    else -> Color.Transparent
                }
            )
            .border(
                width = if (isSelected || isToday) 2.dp else 0.dp,
                color = when {
                    isSelected -> DoziPurple
                    isToday -> DoziTurquoise
                    else -> Color.Transparent
                },
                shape = RoundedCornerShape(16.dp)
            )
            .padding(vertical = 12.dp)
            .clickable(onClick = onClick)
    ) {
        Text(
            dayName,
            style = MaterialTheme.typography.labelSmall,
            color = when {
                isSelected -> DoziPurple
                isToday -> DoziTurquoise
                else -> TextSecondaryLight
            },
            fontWeight = if (isToday || isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 11.sp
        )

        if (isToday) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(id = R.drawable.dozi),
                    contentDescription = "Bugün",
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    "Bugün",
                    style = MaterialTheme.typography.labelSmall,
                    color = DoziTurquoise,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(
                        when (status) {
                            MedicineStatus.TAKEN -> SuccessGreen.copy(alpha = 0.2f)
                            MedicineStatus.SKIPPED -> ErrorRed.copy(alpha = 0.2f)
                            MedicineStatus.PLANNED -> DoziPurple.copy(alpha = 0.1f)
                            else -> VeryLightGray
                        }
                    )
                    .border(
                        width = 2.dp,
                        color = when (status) {
                            MedicineStatus.TAKEN -> SuccessGreen
                            MedicineStatus.SKIPPED -> ErrorRed
                            else -> Color.Transparent
                        },
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                when (status) {
                    MedicineStatus.TAKEN -> Icon(
                        Icons.Default.Check,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    MedicineStatus.SKIPPED -> Icon(
                        Icons.Default.Close,
                        contentDescription = null,
                        tint = ErrorRed,
                        modifier = Modifier.size(16.dp)
                    )
                    else -> Text(
                        date.dayOfMonth.toString(),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (status == MedicineStatus.PLANNED) FontWeight.Bold else FontWeight.Normal,
                        color = if (status == MedicineStatus.PLANNED) DoziPurple else TextPrimaryLight
                    )
                }
            }
        }

        if (status == MedicineStatus.PLANNED && !isToday) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(DoziPurple)
            )
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
private fun CalendarDayDetails(
    date: LocalDate,
    onDismiss: () -> Unit
) {
    // Mock data
    val medicines = listOf(
        MedicineRecord("08:00", "Lustral 100mg", MedicineStatus.TAKEN),
        MedicineRecord("14:00", "Benexol 50mg", MedicineStatus.UPCOMING),
        MedicineRecord("22:00", "Vitamin D3 20mg", MedicineStatus.SKIPPED)
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .shadow(12.dp, RoundedCornerShape(20.dp)),
        color = Color.White,
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${date.dayOfMonth} ${date.month.getDisplayName(TextStyle.FULL, Locale("tr"))}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Kapat", tint = TextSecondaryLight)
                }
            }

            Spacer(Modifier.height(16.dp))

            medicines.forEach { medicine ->
                DayMedicineItem(medicine)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun DayMedicineItem(medicine: MedicineRecord) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                when (medicine.status) {
                    MedicineStatus.TAKEN -> SuccessGreen.copy(alpha = 0.1f)
                    MedicineStatus.SKIPPED -> ErrorRed.copy(alpha = 0.1f)
                    else -> VeryLightGray
                }
            )
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                when (medicine.status) {
                    MedicineStatus.TAKEN -> Icons.Default.CheckCircle
                    MedicineStatus.SKIPPED -> Icons.Default.Cancel
                    else -> Icons.Default.Schedule
                },
                contentDescription = null,
                tint = when (medicine.status) {
                    MedicineStatus.TAKEN -> SuccessGreen
                    MedicineStatus.SKIPPED -> ErrorRed
                    else -> TextSecondaryLight
                },
                modifier = Modifier.size(24.dp)
            )
            Text(
                medicine.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = TextPrimaryLight
            )
        }

        Text(
            medicine.time,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = when (medicine.status) {
                MedicineStatus.TAKEN -> SuccessGreen
                MedicineStatus.SKIPPED -> ErrorRed
                else -> TextSecondaryLight
            }
        )
    }
}

@Composable
private fun CurrentMedicineCard(
    snoozeMinutes: Int,
    onTaken: () -> Unit,
    onSnooze: () -> Unit,
    onSkip: () -> Unit
) {
    val context = LocalContext.current
    var remainingSeconds by remember { mutableStateOf(0) }

    // ✅ snooze_until'e göre kalan süreyi hesapla
    LaunchedEffect(snoozeMinutes) {
        if (snoozeMinutes > 0) {
            val prefs = context.getSharedPreferences("dozi_prefs", Context.MODE_PRIVATE)
            val snoozeUntil = prefs.getLong("snooze_until", 0)

            while (snoozeUntil > System.currentTimeMillis()) {
                val remainingMillis = snoozeUntil - System.currentTimeMillis()
                remainingSeconds = (remainingMillis / 1000).toInt()

                if (remainingSeconds <= 0) break

                delay(1000)
            }

            // Süre doldu
            remainingSeconds = 0
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                color = DoziRed,
                shape = RoundedCornerShape(14.dp),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Place,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "SIRADA",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        letterSpacing = 1.sp
                    )
                }
            }

            if (remainingSeconds > 0) {
                Text(
                    "Ertelendi: ${remainingSeconds / 60}:${(remainingSeconds % 60).toString().padStart(2, '0')}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = WarningOrange
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    Icons.Default.Schedule,
                    contentDescription = null,
                    tint = DoziRed,
                    modifier = Modifier.size(32.dp)
                )
                Text(
                    "14:00",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color = DoziRed
                )
            }

            Text(
                "💊 Aspirin 100mg",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )

            Text(
                "📦 1 tablet",
                style = MaterialTheme.typography.titleSmall,
                color = TextSecondaryLight
            )

            HorizontalDivider(color = VeryLightGray, thickness = 1.dp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ActionButton(
                    text = "AL",
                    icon = Icons.Default.Check,
                    color = SuccessGreen,
                    modifier = Modifier.weight(1f),
                    onClick = onTaken
                )

                ActionButton(
                    text = "ERTELE",
                    icon = Icons.Default.AccessTime,
                    color = WarningOrange,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        playSound(context, R.raw.ertele)
                        onSnooze()
                    }
                )

                ActionButton(
                    text = "ATLA",
                    icon = Icons.Default.Close,
                    color = ErrorRed,
                    modifier = Modifier.weight(1f),
                    onClick = onSkip
                )
            }
        }
    }
}

@Composable
private fun EmptyMedicineCard(status: MedicineStatus) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.dozi_happy),
                contentDescription = null,
                modifier = Modifier.size(100.dp)
            )

            Text(
                when (status) {
                    MedicineStatus.TAKEN -> "Harika! İlacını aldın"
                    MedicineStatus.SKIPPED -> "Bugün için başka ilaç yok"
                    else -> "Henüz ilaç zamanı değil"
                },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight,
                textAlign = TextAlign.Center
            )

            Text(
                when (status) {
                    MedicineStatus.TAKEN -> "Sağlığınla ilgilendiğin için teşekkürler!"
                    MedicineStatus.SKIPPED -> "Yarın için planlanmış ilaçların var"
                    else -> "Vakti gelince seni uyaracağım"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun ActionButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(54.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
        shape = RoundedCornerShape(14.dp),
        elevation = ButtonDefaults.buttonElevation(4.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(22.dp),
                tint = Color.White
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = Color.White
            )
        }
    }
}

@Composable
private fun TimelineSection(
    expanded: Boolean,
    onToggle: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = rememberRipple(),
                    onClick = onToggle
                )
                .padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Bugünün İlaçları",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                Surface(
                    color = DoziTurquoise,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "3",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Icon(
                if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                contentDescription = null,
                tint = DoziTurquoise,
                modifier = Modifier.size(28.dp)
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Spacer(Modifier.height(8.dp))

                TimelineItem(
                    time = "08:00",
                    medicineName = "Lustral 100mg",
                    status = TimelineStatus.COMPLETED,
                    subtitle = "2 saat önce"
                )

                TimelineItem(
                    time = "14:00",
                    medicineName = "Benexol 50mg",
                    status = TimelineStatus.CURRENT,
                    subtitle = "ŞİMDİ"
                )

                TimelineItem(
                    time = "22:00",
                    medicineName = "Vitamin D3",
                    status = TimelineStatus.UPCOMING,
                    subtitle = "8 saat sonra"
                )
            }
        }
    }
}

enum class TimelineStatus {
    COMPLETED, CURRENT, UPCOMING
}

@Composable
private fun TimelineItem(
    time: String,
    medicineName: String,
    status: TimelineStatus,
    subtitle: String
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = when (status) {
                TimelineStatus.COMPLETED -> Color.White
                TimelineStatus.CURRENT -> DoziCoralLight.copy(alpha = 0.15f)
                TimelineStatus.UPCOMING -> Color.White
            } as Color
        ),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = when (status) {
                TimelineStatus.CURRENT -> 2.dp
                else -> 1.dp
            },
            color = when (status) {
                TimelineStatus.COMPLETED -> DoziTurquoise.copy(alpha = 0.4f)
                TimelineStatus.CURRENT -> DoziRed
                TimelineStatus.UPCOMING -> VeryLightGray
            }
        ),
        elevation = CardDefaults.cardElevation(0.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(
                            when (status) {
                                TimelineStatus.COMPLETED -> DoziTurquoise
                                TimelineStatus.CURRENT -> DoziRed
                                TimelineStatus.UPCOMING -> LightGray
                            }
                        )
                )

                Column {
                    Text(
                        medicineName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = when (status) {
                            TimelineStatus.CURRENT -> DoziRed
                            else -> TextSecondaryLight
                        },
                        fontWeight = if (status == TimelineStatus.CURRENT) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            Text(
                time,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = when (status) {
                    TimelineStatus.CURRENT -> DoziRed
                    TimelineStatus.COMPLETED -> DoziTurquoise
                    else -> TextSecondaryLight
                }
            )
        }
    }
}

@Composable
private fun SnoozeDialog(
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    var selectedMinutes by remember { mutableStateOf(10) }
    val options = listOf(10, 15, 30, 60)
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "Ne Kadar Erteleyelim?",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )

                Text(
                    "İlacını almak için biraz daha zamana mı ihtiyacın var?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.forEach { minutes ->
                        SnoozeOption(
                            minutes = minutes,
                            selected = selectedMinutes == minutes,
                            onClick = { selectedMinutes = minutes }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("İptal")
                    }

                    Button(
                        onClick = {
                            // ✅ SharedPreferences'a kaydet
                            context.getSharedPreferences("dozi_prefs", Context.MODE_PRIVATE).edit()
                                .putInt("snooze_minutes", selectedMinutes)
                                .putLong("snooze_until", System.currentTimeMillis() + selectedMinutes * 60_000L)
                                .putLong("snooze_timestamp", System.currentTimeMillis()) // ✅ Zaman damgası
                                .apply()

                            onConfirm(selectedMinutes)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WarningOrange
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Ertele")
                    }
                }
            }
        }
    }
}

@Composable
private fun SnoozeOption(
    minutes: Int,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) WarningOrange.copy(alpha = 0.1f) else VeryLightGray,
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) WarningOrange else Color.Transparent
        )
    ) {
        Text(
            "$minutes dakika",
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            color = if (selected) WarningOrange else TextPrimaryLight,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun SkipReasonDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var selectedReason by remember { mutableStateOf<String?>(null) }

    val reasons = listOf(
        "Zaten aldım",
        "Daha sonra alacağım",
        "İlacım bitti",
        "Yan etki yaşadım",
        "Unutmuşum",
        "Doktor değiştirdi",
        "Kendimi iyi hissediyorum",
        "Diğer"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "Neden Atlamak İstiyorsun?",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )

                Text(
                    "İlaç takibini daha iyi yapabilmem için nedenini öğrenmek isterim.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    reasons.forEach { reason ->
                        ReasonChip(
                            text = reason,
                            selected = selectedReason == reason,
                            onClick = { selectedReason = reason }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("İptal")
                    }

                    Button(
                        onClick = {
                            selectedReason?.let { onConfirm(it) }
                        },
                        modifier = Modifier.weight(1f),
                        enabled = selectedReason != null,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DoziRed
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Atla")
                    }
                }
            }
        }
    }
}

@Composable
private fun ReasonChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) DoziRed.copy(alpha = 0.1f) else VeryLightGray,
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) DoziRed else Color.Transparent
        )
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            color = if (selected) DoziRed else TextPrimaryLight,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}