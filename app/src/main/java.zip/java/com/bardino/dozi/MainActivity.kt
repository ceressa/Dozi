package com.bardino.dozi

import android.Manifest
import android.app.AlarmManager
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.navigation.compose.rememberNavController
import com.bardino.dozi.core.data.IlacRepository
import com.bardino.dozi.core.data.OnboardingPreferences
import com.bardino.dozi.navigation.NavGraph
import com.bardino.dozi.notifications.NotificationHelper
import com.bardino.dozi.core.ui.theme.DoziAppTheme
import com.bardino.dozi.navigation.Screen
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    // 🔹 Çoklu izin isteyici (bildirim, kamera, konum)
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            handlePermissionResults(permissions)
        }

    // 🔹 Overlay izni için ayrı launcher
    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            // Sessizce kontrol et, gereksiz toast gösterme
        }

    // 🔹 Exact Alarm izni için launcher
    private val exactAlarmLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            // Sessizce kontrol et, gereksiz toast gösterme
        }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            DoziAppTheme {
                val navController = rememberNavController()
                NavGraph(
                    navController = navController,
                    startDestination = Screen.Home.route
                )
            }
        }

    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        // 🔔 Bildirim izni (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // 📷 Kamera izni
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }

        // 📍 Konum izinleri
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted && !coarseGranted) {
            permissionsToRequest.addAll(
                listOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }

        // 🔹 Standart izinleri iste
        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            // Tüm standart izinler verilmiş, kanal oluştur
            NotificationHelper.createDoziChannel(this)

            // Şimdi özel izinleri kontrol et
            checkSpecialPermissions()
        }
    }

    private fun handlePermissionResults(permissions: Map<String, Boolean>) {
        val notifGranted = permissions[Manifest.permission.POST_NOTIFICATIONS] ?: true
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: true
        val locationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: true

        // 🔔 Bildirim izni
        if (notifGranted) {
            NotificationHelper.createDoziChannel(this)
            Toast.makeText(this, "✅ Bildirim izni verildi", Toast.LENGTH_SHORT).show()

            // Standart izinler tamam, şimdi özel izinleri kontrol et
            checkSpecialPermissions()
        } else {
            Toast.makeText(
                this,
                "💧 Dozi: Bildirim izni olmadan seni zamanında uyaramam.",
                Toast.LENGTH_LONG
            ).show()
        }

        // 📷 Kamera izni
        if (!cameraGranted) {
            Toast.makeText(
                this,
                "📷 Kamera izni verilmedi (İlaç barkod okuma çalışmayacak)",
                Toast.LENGTH_SHORT
            ).show()
        }

        // 📍 Konum izni
        if (!locationGranted) {
            Toast.makeText(
                this,
                "📍 Konum izni verilmedi (Eczane bulma çalışmayacak)",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun checkSpecialPermissions() {
        // 🎯 Overlay iznini sadece ilk sefer iste
        val prefs = getSharedPreferences("dozi_prefs", MODE_PRIVATE)
        val overlayAsked = prefs.getBoolean("overlay_asked", false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this) && !overlayAsked) {
                prefs.edit().putBoolean("overlay_asked", true).apply()
                // Dialog göster, direkt isteme
                showOverlayPermissionDialog()
            }
        }

        // ⏰ Exact Alarm iznini sadece ilk sefer iste
        val alarmAsked = prefs.getBoolean("alarm_asked", false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(AlarmManager::class.java)
            if (!alarmManager.canScheduleExactAlarms() && !alarmAsked) {
                prefs.edit().putBoolean("alarm_asked", true).apply()
                // Dialog göster, direkt isteme
                showExactAlarmPermissionDialog()
            }
        }
    }

    private fun showOverlayPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("💧 Dozi - Ek İzin")
            .setMessage("İlaç erteleme dialog'unu gösterebilmem için 'Diğer uygulamaların üzerinde gösterim' iznine ihtiyacım var.\n\nBu izin olmadan erteleme özelliği çalışmayacak.")
            .setPositiveButton("İzin Ver") { _, _ ->
                requestOverlayPermission()
            }
            .setNegativeButton("Şimdi Değil", null)
            .show()
    }

    private fun showExactAlarmPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("💧 Dozi - Alarm İzni")
            .setMessage("İlaç hatırlatmalarını tam zamanında verebilmem için alarm izni gerekiyor.\n\nBu izin olmadan hatırlatmalar gecikebilir.")
            .setPositiveButton("İzin Ver") { _, _ ->
                requestExactAlarmPermission()
            }
            .setNegativeButton("Şimdi Değil", null)
            .show()
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:$packageName")
            }
            exactAlarmLauncher.launch(intent)
        }
    }
}