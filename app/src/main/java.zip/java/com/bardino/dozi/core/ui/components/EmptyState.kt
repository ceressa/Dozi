package com.bardino.dozi.core.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.bardino.dozi.core.ui.theme.*

@Composable
fun EmptyState(
    @DrawableRes icon: Int,
    title: String,
    description: String,
    modifier: Modifier = Modifier,
    actionButton: @Composable (() -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // İkon
        Image(
            painter = painterResource(id = icon),
            contentDescription = null,
            modifier = Modifier
                .size(140.dp)
                .padding(bottom = 24.dp)
        )

        // Başlık
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(8.dp))

        // Açıklama
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        // Opsiyonel aksiyon butonu
        if (actionButton != null) {
            Spacer(Modifier.height(24.dp))
            actionButton()
        }
    }
}

// 🎨 PRESET EMPTY STATES
@Composable
fun EmptyMedicineList(
    onAddMedicine: () -> Unit
) {
    EmptyState(
        icon = com.bardino.dozi.R.drawable.dozi_noted2,
        title = "Henüz ilaç eklemediniz",
        description = "İlaçlarınızı ekleyerek takibini kolaylaştırın",
        actionButton = {
            Button(
                onClick = onAddMedicine,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DoziTurquoise
                ),
                shape = MaterialTheme.shapes.medium
            ) {
                Text("İlk İlacı Ekle")
            }
        }
    )
}

@Composable
fun EmptyReminderList(
    onAddReminder: () -> Unit
) {
    EmptyState(
        icon = com.bardino.dozi.R.drawable.dozi_noted,
        title = "Henüz hatırlatma yok",
        description = "İlaç hatırlatmaları kurarak hiçbir dozu kaçırmayın",
        actionButton = {
            Button(
                onClick = onAddReminder,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DoziCoral
                ),
                shape = MaterialTheme.shapes.medium
            ) {
                Text("Hatırlatma Kur")
            }
        }
    )
}

@Composable
fun EmptySearchResults() {
    EmptyState(
        icon = com.bardino.dozi.R.drawable.dozi,
        title = "Sonuç bulunamadı",
        description = "Arama kriterlerinizi değiştirip tekrar deneyin"
    )
}