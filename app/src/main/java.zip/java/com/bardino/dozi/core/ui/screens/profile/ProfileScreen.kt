package com.bardino.dozi.core.ui.screens.profile

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.bardino.dozi.R
import com.bardino.dozi.core.ui.components.DoziTopBar
import com.bardino.dozi.core.ui.theme.*
import com.bardino.dozi.notifications.NotificationHelper

@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onNavigateBack: () -> Unit,
    onNavigateToAccount: () -> Unit = {},
    onNavigateToNotifications: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {},
    onNavigateToAbout: () -> Unit = {},
    onNavigateToLocations: () -> Unit = {}
) {
    val context = LocalContext.current
    var isVisible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { isVisible = true }

    // Bildirim izni
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            NotificationHelper.showMedicationNotification(context, "Test İlaç")
        } else {
            Toast.makeText(context, "Bildirim izni verilmedi.", Toast.LENGTH_SHORT).show()
        }
    }

    var savedLocations by remember { mutableStateOf(mutableListOf<String>()) }
    var isLocationDialogVisible by remember { mutableStateOf(false) }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(context, "📍 Konum izni verilmedi.", Toast.LENGTH_SHORT).show()
        }
    }


    Scaffold(
        topBar = {
            DoziTopBar(
                title = "Profil",
                canNavigateBack = false,
                backgroundColor = Color.White
            )
        },
        containerColor = BackgroundLight
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 🧍‍♂️ Kullanıcı Bölümü
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn() + slideInVertically(initialOffsetY = { -60 })
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(DoziTurquoise, DoziBlue)
                            )
                        )
                        .padding(vertical = 40.dp, horizontal = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Avatar
                        Surface(
                            modifier = Modifier.size(110.dp),
                            color = Color.White,
                            shape = CircleShape,
                            tonalElevation = 8.dp
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Person,
                                    contentDescription = null,
                                    tint = DoziTurquoise,
                                    modifier = Modifier.size(64.dp)
                                )
                            }
                        }

                        // Kullanıcı Bilgisi
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Ufuk Çelikeloglu",
                                style = MaterialTheme.typography.headlineSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Senior Technology Specialist • FedEx",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                            Surface(
                                color = Color.White.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text(
                                    text = "Ücretsiz Plan",
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(30.dp))

            // Menü Alanı
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                AnimatedVisibility(
                    visible = isVisible,
                    enter = fadeIn(tween(600)) + slideInVertically(initialOffsetY = { 40 })
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        MenuCard(
                            icon = Icons.Default.Star,
                            title = "Premium'a Geç",
                            desc = "Tüm özellikleri sınırsız kullan",
                            color = DoziCoral,
                            onClick = { /* Premium ekranı */ },
                            highlight = true
                        )

                        MenuCard(
                            icon = Icons.Default.AccountCircle,
                            title = "Hesap Bilgileri",
                            desc = "Kişisel bilgilerini görüntüle veya düzenle",
                            color = DoziTurquoise,
                            onClick = onNavigateToAccount
                        )

                        MenuCard(
                            icon = Icons.Default.Notifications,
                            title = "Bildirim Ayarları",
                            desc = "Hatırlatma tercihlerini yönet",
                            color = DoziBlue,
                            onClick = onNavigateToNotifications
                        )

                        MenuCard(
                            icon = Icons.Default.Place,
                            title = "Konumlarım",
                            desc = "Ev, iş, okul gibi yerleri kaydet",
                            color = DoziTurquoise,
                            onClick = onNavigateToLocations
                        )


                        MenuCard(
                            icon = Icons.Default.Settings,
                            title = "Uygulama Ayarları",
                            desc = "Tema, dil ve genel tercihler",
                            color = WarningOrange,
                            onClick = onNavigateToSettings
                        )

                        MenuCard(
                            icon = Icons.Default.Info,
                            title = "Hakkında",
                            desc = "Sürüm, gizlilik ve iletişim bilgileri",
                            color = TextSecondary,
                            onClick = onNavigateToAbout
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))

                // Test bildirimi
                OutlinedButton(
                    onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            if (ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.POST_NOTIFICATIONS
                                ) == PackageManager.PERMISSION_GRANTED
                            ) {
                                NotificationHelper.showMedicationNotification(context, "Test İlaç")
                            } else {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        } else {
                            NotificationHelper.showMedicationNotification(context, "Test İlaç")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DoziTurquoise)
                ) {
                    Icon(Icons.Default.Notifications, null)
                    Spacer(Modifier.width(8.dp))
                    Text("🧪 Test Bildirim Gönder")
                }
            }

            Spacer(Modifier.height(100.dp))
        }
    }
}

// 🌟 Menü Kartı
@Composable
private fun MenuCard(
    icon: ImageVector,
    title: String,
    desc: String,
    color: Color,
    onClick: () -> Unit,
    highlight: Boolean = false
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (highlight)
                color.copy(alpha = 0.12f)
            else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (highlight) 3.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                modifier = Modifier.size(46.dp),
                shape = CircleShape,
                color = color.copy(alpha = 0.15f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, null, tint = color)
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (highlight) color else TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Icon(
                Icons.Default.ChevronRight,
                contentDescription = null,
                tint = TextSecondary
            )
        }
    }
}
